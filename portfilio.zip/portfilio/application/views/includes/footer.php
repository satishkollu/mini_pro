</div>
<!--   Core JS Files   -->
<script src="../../assets/js/core/jquery.min.js" type="text/javascript"></script>
<script src="../../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../../assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
<script src="../../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="../../assets/js/plugins/moment.min.js" type="text/javascript"></script>
<script src="../../assets/js/plugins/date-picker.min.js" type="text/javascript"></script>

<!--    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>-->
<!-- Chartist JS -->
<script src="../../assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="../../assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../../assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
<script src="../../assets/plugins/jquery-easing/jquery.easing.min.js" type="text/javascript"></script>
<script src="../../assets/plugins/resume/resume.min.js" type="text/javascript"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="../../assets/demo/demo.js"></script>
<script src="../../assets/js/custom.js"></script>
<script src="../../assets/js/project.js"></script>
<script src="../../assets/js/experience.js"></script>

<script>
    $(document).ready(function() {
        // Javascript method's body can be found in ../../assets/js/demos.js
        md.initDashboardPageCharts();

    });

</script>
</body>

</html>
